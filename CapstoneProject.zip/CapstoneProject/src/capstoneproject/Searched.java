package capstoneproject;

public class Searched {
    static String name;
    

    public Searched(String name) {
    this.name = name;
}
}
